import os.path
import pandas as pd
import numpy as np
from excel_parser.load_and_clean_tabular_data import load_and_clean_excel
from mortgage_model_fast import run_mortgage_model
from timeseries_formater.constants import SMALL_FLOAT
from timeseries_formater.create_timeseries_by_trade_id import create_timeseries_by_id_and_date
from timeseries_formater.metric_functions import current_balance, seasoning, n_missed_payments, prepaid_in_month, \
    default_in_month, recovery_in_month, is_recovery_payment, time_to_reversion, is_post_seller_purchase_date, \
    postdefault_recoveries, prepayment_date, date_of_default, date_of_recovery, exposure_at_default, recovery_percent, \
    portfolio_prepayment_rate, cumulative_default_rate, cumulative_recovery_rate, months_since_default, year_of_default, \
    create_probability_of_default, create_recovery_rate_from_rec_over_ead
from utilities.check_for_datetime_columns import check_date_columns
from utilities.df_utilities import clip_df_at_given_index_and_convert_to_numpy_array
from utilities.object_to_and_from_pickle import save_pickle, load_pickle

# File paths
file_path = '2024 - Strat Casestudy.xlsx'  # Path to the Excel file
pickle_path = 'pickles/cleansed_dataframe.pkl'  # Path to save/load the cleaned dataframes

# Load and clean the Excel file if pickle does not exist
if not os.path.exists(pickle_path):
    cleaned_dataframes = load_and_clean_excel(file_path)  # Load and clean data from Excel
    save_pickle(cleaned_dataframes, pickle_path)  # Save cleaned data to a pickle file
else:
    cleaned_dataframes = load_pickle(pickle_path)  # Load cleaned data from pickle file

# Define metrics to be calculated
metrics = {
    'current_balance': current_balance,
    'seasoning': seasoning,
    'n_missed_payments': n_missed_payments,
    'prepaid_in_month': prepaid_in_month,
    'default_in_month': default_in_month,
    'recovery_in_month': recovery_in_month,
    'is_recovery_payment': is_recovery_payment,
    'time_to_reversion': time_to_reversion,
    'is_post_seller_purchase_date': is_post_seller_purchase_date,
    'postdefault_recoveries': postdefault_recoveries,
    'prepayment_date': prepayment_date,
    'date_of_default': date_of_default,
    'date_of_recovery': date_of_recovery,
    'exposure_at_default': exposure_at_default,
    'recovery_percent': recovery_percent,
    'months_since_default': months_since_default,
    'year_of_default': year_of_default,
}

# Create time series data by loan ID and date
pickle_path = 'pickles/meltable_tables.pkl'  # Path to save/load the meltable tables
if not os.path.exists(pickle_path):
    meltable_tables = create_timeseries_by_id_and_date(cleaned_dataframes, metrics)  # Create timeseries data
    save_pickle(meltable_tables, pickle_path)  # Save timeseries data to a pickle file
else:
    meltable_tables = load_pickle(pickle_path)  # Load timeseries data from pickle file

# portfolio_prepayment_rate(meltable_tables, ['seasoning'])
# cumulative_default_rate(meltable_tables)
#
# # create_recovery_rate_from_rec_over_ead(meltable_tables)
# # Calculate and print cumulative recovery rate
# cumulative_recovery_rate(meltable_tables, ['year_of_default'])
# # Calculate and print cumulative recovery rate grouped by time to reversion and product
# cumulative_recovery_rate(meltable_tables, ['time_to_reversion', 'product'])
# # Calculate and print single month mortality rate grouped by time to reversion and product
# portfolio_prepayment_rate(meltable_tables, ['time_to_reversion', 'product'])
# # Calculate and print cumulative default rate
# cumulative_default_rate(meltable_tables)
# # Placeholder for future code or operations
# pass

cpr_path = 'pickles/cpr.pkl'
cdr_path = 'pickles/cdr.pkl'
rec_path = 'pickles/rec.pkl'

if not (os.path.exists(cpr_path) and os.path.exists(cdr_path) and os.path.exists(rec_path)):
    cpr_curve = portfolio_prepayment_rate(meltable_tables, ['seasoning'])
    cdr_curve = cumulative_default_rate(meltable_tables, ['seasoning'])
    recovery_curve = cumulative_recovery_rate(meltable_tables, ['seasoning'])

    cpr_curve = clip_df_at_given_index_and_convert_to_numpy_array(cpr_curve, 0)
    cdr_curve = clip_df_at_given_index_and_convert_to_numpy_array(cdr_curve, 0)
    recovery_curve = clip_df_at_given_index_and_convert_to_numpy_array(recovery_curve, 0)

    save_pickle(cpr_curve, cpr_path)  # Save timeseries data to a pickle file
    save_pickle(cdr_curve, cdr_path)  # Save timeseries data to a pickle file
    save_pickle(recovery_curve, rec_path)  # Save timeseries data to a pickle file
else:
    cpr_curve = load_pickle(cpr_path)
    cdr_curve = load_pickle(cdr_path)
    recovery_curve = load_pickle(rec_path)


assert cpr_curve.shape == cdr_curve.shape == recovery_curve.shape, 'Curve Shapes are not Consistent, please check'

grouped = meltable_tables.groupby('loan_id')

loan_params = []

boe_base_rate = 0.0525

for name, group in grouped:
    index_where_seasoning_is_0 = np.where(group['seasoning'] == 0)[0][0]
    row_where_index_seasoning_is_0 = group.loc[group.index[index_where_seasoning_is_0]]
    assert row_where_index_seasoning_is_0['MonthEndBalances'] != 0, 'Loan Month End balance at seasoning is 0'
    loan_params.append(
        {
            'loan_id': row_where_index_seasoning_is_0['loan_id'],
            'current_balance': row_where_index_seasoning_is_0['MonthEndBalances'],
            'fixed_pre_reversion_rate': row_where_index_seasoning_is_0['pre_reversion_fixed_rate'],
            'post_reversion_margin': row_where_index_seasoning_is_0['post_reversion_boe_margin'],
            'months_to_maturity': len(cpr_curve),
            'repayment_method': 'Interest Only',
            'boe_curve': np.zeros_like(cpr_curve) * boe_base_rate,
            'scenario': ['base'],
            'cpr_curve': cpr_curve,
            'cdr_curve': cdr_curve,
            'recovery_curve': recovery_curve,
            'time_to_reversion': -row_where_index_seasoning_is_0['time_to_reversion'],
            'product': row_where_index_seasoning_is_0['product']
        }
    )

# todo Runtime is 1 second for N = 1,630 loans which can be improved. I can fix this if I get time but I did not want to
#  sacrifice debugging interpretability (df output is easier to read by a human, especially if not in production);
#  To improve speed I would use multidimensional numpy arrays for storage and then split them in chunks for dask to
#  parse more efficiently.

mortgage_level_data, portfolio_level_data = run_mortgage_model(loan_params)

monthly_prepayment_rate = 1 - np.power(1 - portfolio_level_data['monthly_prepayments'] / portfolio_level_data['monthly_opening_balance'], 12)
monthly_default_rate = 1 - np.power(1 - portfolio_level_data['monthly_defaults'] / portfolio_level_data['monthly_opening_balance'], 12)
monthly_recovery_rate = 100 * portfolio_level_data['monthly_recoveries'] / (portfolio_level_data['monthly_defaults'] + SMALL_FLOAT)

print(
    f'Difference between Monthly Prepayment Rate average vs Realised Prepayment Rate average = {np.average(monthly_prepayment_rate - cpr_curve)}')
print(
    f'Difference between Monthly Default Rate average vs Realised Default Rate average = {np.average(monthly_default_rate - cdr_curve)}')

# For the full solution please refer to the Jupyter Notebook
