def standardize_columns(df, key=None):
    df_cols = df.columns.to_list()
    df_cols[key] = df.columns[key].lower()
    df.columns = df_cols
    return df