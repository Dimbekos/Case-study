def clip_df_at_given_index_and_convert_to_numpy_array(df, index_in):
    return df[df.index >= index_in].values[:, 0]
