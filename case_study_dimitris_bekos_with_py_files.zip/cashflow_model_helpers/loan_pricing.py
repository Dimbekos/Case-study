def pmt(rate, nper, pv, fv=0, when='end'):
    """
    Calculate the payment for a loan based on constant payments and a constant interest rate.

    :param rate: The periodic interest rate (as a decimal, e.g., 0.05 for 5%)
    :param nper: The number of periods (e.g., number of months or years)
    :param pv: The present value (loan amount)
    :param fv: The future value (loan balance after last payment, default is 0)
    :param when: When payments are due ('begin' for beginning of period, 'end' for end of period)
    :return: The payment amount
    """
    if rate == 0:
        return -(pv + fv) / nper

    if when == 'begin':
        return -(rate * (pv * (1 + rate) ** nper + fv)) / ((1 + rate) * ((1 + rate) ** nper - 1))
    else:
        return -(rate * (pv * (1 + rate) ** nper + fv)) / (((1 + rate) ** nper - 1))