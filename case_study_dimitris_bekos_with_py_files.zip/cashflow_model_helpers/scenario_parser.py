import numpy as np


def scenario_parser(params, cpr_by_month, cdr_by_month, recovery_by_month):
    scenarios = params['scenario']

    # Initialize the result with the base values
    result_cpr = cpr_by_month.copy()
    result_cdr = cdr_by_month.copy()
    result_recovery = recovery_by_month.copy()

    # Process each scenario
    for scenario in scenarios:
        if scenario == 'base':
            return result_cpr, result_cdr, result_recovery
        metric = scenario['metric'].upper()
        factor = scenario['factor']
        filter_conditions = scenario.get('filter', {})

        # Determine the range of indices to apply the factor based on filters
        indices = np.arange(len(cpr_by_month))

        if filter_conditions.get('PostReversion'):
            reversion_index = params['time_to_reversion']
            indices = indices[reversion_index+1:]

        if filter_conditions.get('AtReversion'):
            reversion_index = params['time_to_reversion']
            indices = indices[reversion_index]

        if 'Product' in filter_conditions:
            if params['product'] != filter_conditions['Product']:
                continue  # Skip this modification if the product does not match

        if filter_conditions.get('MonthOfReversion'):
            reversion_index = params['time_to_reversion']
            indices = np.array([reversion_index])

        # Apply the factor to the relevant metric
        if metric == 'CPR':
            result_cpr[indices] *= factor
        elif metric == 'CDR':
            result_cdr[indices] *= factor
        elif metric == 'RECOVERY' and not filter_conditions.get('LinearRecovery'):
            result_recovery[indices] *= factor
        else:
            raise ValueError(f"Unknown metric or condition: {metric}")

    return result_cpr, result_cdr, result_recovery


if __name__ == '__main__':

    cpr_by_month = np.array([0.01, 0.02, 0.03, 0.04])
    cdr_by_month = np.array([0.005, 0.01, 0.015, 0.02])
    recovery_by_month = np.array([0.002, 0.004, 0.006, 0.008])

    params = {
        'loan_id': np.int64(1),
        'current_balance': np.float64(150876.0),
        'fixed_pre_reversion_rate': np.float64(0.0198807203580582),
        'post_reversion_margin': np.float64(0.0375),
        'months_to_maturity': 85,
        'repayment_method': 'Interest Only',
        'scenario': [
            {'metric': 'CPR', 'factor': 2, 'filter': {'PostReversion': True}},
            {'metric': 'CPR', 'factor': 2, 'filter': {'Product': 2, 'PostReversion': True}},
            {'metric': 'CPR', 'factor': 1, 'filter': {'Product': 1, 'MonthOfReversion': True}},
            {'metric': 'Recovery', 'factor': 1}
        ],
        'time_to_reversion': 1,
        'cpr_curve': cpr_by_month,
        'cdr_curve': cdr_by_month,
        'recovery_curve': recovery_by_month,
        'product': 1,
    }

    # Test with a single string
    print(scenario_parser(params, cpr_by_month, cdr_by_month, recovery_by_month))

