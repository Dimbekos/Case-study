import numpy as np
import pandas as pd

from cashflow_model_helpers.loan_pricing import pmt
from utilities.timer import timer

@timer
def main():
    # Define mortgage parameters
    month_post_reversion = -22.00
    seasoning = 2.00
    current_balance = 100000.00
    fixed_pre_reversion_rate = 3.94 / 100  # Convert percentage to decimal
    post_reversion_margin = 4.94 / 100  # Convert percentage to decimal
    months_to_maturity = 178
    repayment_method = "Repayment"
    ls = 0.2
    recovery_lag = 6

    months = np.arange(month_post_reversion, months_to_maturity)
    cpr_by_month = np.ones_like(months) * 0.02
    cdr_by_month = np.ones_like(months) * 0.02
    cpr_by_month[np.where(months == 0)[0][0]-1:] = 0.1
    cdr_by_month[9:] = 0.01


    forecast_months = np.arange(0, len(months))
    boe_rate = np.ones_like(months) * 0.045

    expected_opening_performing_balance = np.zeros_like(boe_rate)
    cdr = np.zeros_like(boe_rate)
    defaults = np.zeros_like(boe_rate)
    expected_balance_period_post_defaults = np.zeros_like(boe_rate)
    survival_pct_post_default = np.zeros_like(boe_rate)
    expected_scheduled_payment = np.zeros_like(boe_rate)
    expected_interest = np.zeros_like(boe_rate)
    expected_principal_schedule = np.zeros_like(boe_rate)
    expected_balance_pre_period_prepays = np.zeros_like(boe_rate)
    cpr = np.zeros_like(boe_rate)
    expected_prepayments = np.zeros_like(boe_rate)
    expected_closing_performing_balance = np.zeros_like(boe_rate)
    end_of_period_survival = np.zeros_like(boe_rate)
    expected_opening_default_balance = np.zeros_like(boe_rate)
    expected_new_defaults = np.zeros_like(boe_rate)
    expected_recoveries = np.zeros_like(boe_rate)
    expected_loss = np.zeros_like(boe_rate)
    expected_closing_default_balance = np.zeros_like(boe_rate)
    opening_balance = np.zeros_like(boe_rate)

    expected_opening_performing_balance[0] = current_balance
    opening_balance[0] = current_balance
    expected_opening_default_balance[0] = 0

    for i in range(10000):
        for i in range(months_to_maturity):
            cdr[i] = cdr_by_month[i]
            defaults[i] = (1 - np.power(1 - cdr[i], 1/12)) * expected_opening_performing_balance[i]
            expected_balance_period_post_defaults[i] = expected_opening_performing_balance[i] - defaults[i]
            survival_pct_post_default[i] = expected_balance_period_post_defaults[i] / opening_balance[i]
            interest_rate = fixed_pre_reversion_rate if months[i] < 0 else post_reversion_margin + boe_rate[i]
            scheduled_interest = interest_rate / 12 * opening_balance[i]
            if repayment_method == 'Repayment':
                scheduled_payment = -pmt(interest_rate/12, months_to_maturity-i, opening_balance[i])
            else:
                scheduled_payment = scheduled_interest
            principal_payment = scheduled_payment - scheduled_interest if 'Repayment' else 0
            principal_payment = opening_balance[i] if i == months_to_maturity else principal_payment
            opening_balance[i+1] = opening_balance[i] - scheduled_payment + scheduled_interest
            expected_scheduled_payment[i] = survival_pct_post_default[i] * scheduled_payment
            expected_interest[i] = survival_pct_post_default[i] * scheduled_interest
            expected_principal_schedule[i] = survival_pct_post_default[i] * principal_payment
            expected_balance_pre_period_prepays[i] = expected_balance_period_post_defaults[i] - expected_principal_schedule[i]
            cpr[i] = cpr_by_month[i]
            expected_prepayments[i] = (1 - np.power(1 - cpr[i], 1/12)) * expected_balance_pre_period_prepays[i]
            expected_closing_performing_balance[i] = expected_balance_pre_period_prepays[i] - expected_prepayments[i]
            end_of_period_survival[i] = expected_closing_performing_balance[i] / opening_balance[i+1]

            expected_new_defaults[i] = defaults[i]
            if i > recovery_lag:
                expected_recoveries[i] = (1 - ls) * expected_new_defaults[i - recovery_lag]
                expected_loss[i] = ls * expected_new_defaults[i - recovery_lag]

            expected_closing_default_balance[i] = expected_opening_default_balance[i] + expected_new_defaults[i] - expected_recoveries[i] - expected_loss[i]
            expected_opening_default_balance[i+1] = expected_closing_default_balance[i]
            expected_opening_performing_balance[i+1] = expected_closing_performing_balance[i]


if __name__ == '__main__':
    main()