import numpy as np
import pandas as pd
from dask import delayed, compute
from cashflow_model_helpers.loan_pricing import pmt
from cashflow_model_helpers.scenario_parser import scenario_parser
from utilities.timer import timer


def process_loan(loan_params):
    current_balance = loan_params['current_balance']
    fixed_pre_reversion_rate = loan_params['fixed_pre_reversion_rate']
    post_reversion_margin = loan_params['post_reversion_margin']
    months_to_maturity = loan_params['months_to_maturity']
    repayment_method = loan_params['repayment_method']
    # recovery_lag = loan_params['recovery_lag']
    boe_rate = np.array(loan_params['boe_curve'])
    cdr_by_month = np.array(loan_params['cdr_curve'])
    cpr_by_month = np.array(loan_params['cpr_curve'])
    recovery_by_month = np.array(loan_params['recovery_curve'])

    cpr_by_month, cdr_by_month, recovery_by_month = scenario_parser(loan_params, cpr_by_month, cdr_by_month, recovery_by_month)

    months = np.arange(len(cpr_by_month))
    expected_opening_performing_balance = np.zeros([len(boe_rate) + 1], dtype=np.float64)
    cdr = np.zeros_like(boe_rate)
    defaults = np.zeros_like(boe_rate)
    expected_balance_period_post_defaults = np.zeros_like(boe_rate)
    survival_pct_post_default = np.zeros_like(boe_rate)
    expected_scheduled_payment = np.zeros_like(boe_rate)
    expected_interest = np.zeros_like(boe_rate)
    expected_principal_schedule = np.zeros_like(boe_rate)
    expected_balance_pre_period_prepays = np.zeros_like(boe_rate)
    cpr = np.zeros_like(boe_rate)
    expected_prepayments = np.zeros_like(boe_rate)
    expected_closing_performing_balance = np.zeros_like(boe_rate)
    end_of_period_survival = np.zeros_like(boe_rate)
    expected_opening_default_balance = np.zeros([len(boe_rate) + 1], dtype=np.float64)
    expected_new_defaults = np.zeros_like(boe_rate)
    expected_recoveries = np.zeros_like(boe_rate)
    expected_loss = np.zeros_like(boe_rate)
    expected_closing_default_balance = np.zeros_like(boe_rate)
    opening_balance = np.zeros([len(boe_rate) + 1], dtype=np.float64)

    expected_opening_performing_balance[0] = current_balance
    opening_balance[0] = current_balance
    expected_opening_default_balance[0] = 0

    for i in range(months_to_maturity):
        cdr[i] = cdr_by_month[i]
        defaults[i] = (1 - np.power(1 - min(cdr[i], 1), 1/12)) * expected_opening_performing_balance[i]
        expected_balance_period_post_defaults[i] = expected_opening_performing_balance[i] - defaults[i]
        survival_pct_post_default[i] = expected_balance_period_post_defaults[i] / opening_balance[i]
        interest_rate = fixed_pre_reversion_rate if months[i] < 0 else post_reversion_margin + boe_rate[i]
        scheduled_interest = interest_rate / 12 * opening_balance[i]
        if repayment_method == 'Repayment':
            scheduled_payment = -pmt(interest_rate/12, months_to_maturity-i, opening_balance[i])
        else:
            scheduled_payment = scheduled_interest
        principal_payment = scheduled_payment - scheduled_interest if repayment_method == 'Repayment' else 0
        principal_payment = opening_balance[i] if i == months_to_maturity else principal_payment
        opening_balance[i+1] = opening_balance[i] - scheduled_payment + scheduled_interest
        expected_scheduled_payment[i] = survival_pct_post_default[i] * scheduled_payment
        expected_interest[i] = survival_pct_post_default[i] * scheduled_interest
        expected_principal_schedule[i] = survival_pct_post_default[i] * principal_payment
        expected_balance_pre_period_prepays[i] = expected_balance_period_post_defaults[i] - expected_principal_schedule[i]
        cpr[i] = cpr_by_month[i]
        expected_prepayments[i] = (1 - np.power(1 - min(cpr[i], 1), 1/12)) * expected_balance_pre_period_prepays[i]
        expected_closing_performing_balance[i] = expected_balance_pre_period_prepays[i] - expected_prepayments[i]
        end_of_period_survival[i] = expected_closing_performing_balance[i] / opening_balance[i+1]
        expected_new_defaults[i] = defaults[i]
        expected_recoveries[i] = recovery_by_month[i] / 100 * expected_new_defaults[i]
        expected_loss[i] = (1 - recovery_by_month[i] / 100) * expected_new_defaults[i]

        expected_closing_default_balance[i] = round(expected_opening_default_balance[i] + expected_new_defaults[i] - expected_recoveries[i] - expected_loss[i])
        expected_opening_default_balance[i+1] = expected_closing_default_balance[i]
        expected_opening_performing_balance[i+1] = expected_closing_performing_balance[i]

    df_out = pd.DataFrame(
        np.array(
            [expected_opening_performing_balance[:-1], expected_closing_performing_balance, expected_principal_schedule, expected_interest, expected_prepayments,
             expected_new_defaults, expected_recoveries, expected_loss, expected_closing_default_balance, cpr, cdr, recovery_by_month]).T,
        columns=['expected_opening_performing_balance', 'expected_closing_performing_balance', 'expected_principal_schedule', 'expected_interest',
                 'expected_prepayments', 'expected_new_defaults', 'expected_recoveries', 'expected_loss',
                 'expected_closing_default_balance', 'cpr', 'cdr', 'recovery_by_month'],
        index=range(months_to_maturity)
    )

    return df_out

# Function to parallelize the loan processing
@timer
def parallel_process_loans(loan_params_list):
    # Create a list of delayed objects
    delayed_results = [delayed(process_loan)(row) for row in loan_params_list]

    # Compute the results
    results = compute(delayed_results)

    return results[0]


def get_monthly_results(results):
    total_prepayments = np.zeros(results[0].shape[0])
    total_principal = np.zeros(results[0].shape[0])
    total_defaults = np.zeros(results[0].shape[0])
    total_recoveries = np.zeros(results[0].shape[0])
    total_balance = np.zeros(results[0].shape[0])
    total_closing_defaults = np.zeros(results[0].shape[0])
    for i in range(len(results)):

        total_prepayments += results[i]['expected_prepayments'].values
        total_principal += results[i]['expected_principal_schedule'].values
        total_defaults += results[i]['expected_new_defaults'].values
        total_recoveries += results[i]['expected_recoveries'].values
        total_balance += results[i]['expected_opening_performing_balance'].values
        total_closing_defaults += results[i]['expected_closing_default_balance'].values

    return pd.DataFrame(
        np.array([total_prepayments, total_principal, total_defaults, total_recoveries, total_balance, total_closing_defaults]).T,
        columns=['monthly_prepayments', 'monthly_principal', 'monthly_defaults', 'monthly_recoveries', 'monthly_opening_balance', 'monthly_closing_default_balance'],
    )


def run_mortgage_model(loan_params_list):

    # Process the loans in parallel
    results = parallel_process_loans(loan_params_list)
    monthly_results = get_monthly_results(results)
    return results, monthly_results