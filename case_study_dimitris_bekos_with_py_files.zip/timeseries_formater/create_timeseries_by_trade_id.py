import pandas as pd
from utilities.check_for_datetime_columns import check_date_columns
from utilities.standardise_columns import standardize_columns


def combine_loan_level_data(filtered_dataframes, timeseries_id='loan_id', var_name='date', standardize_column_key=0):
    timeseries_id = timeseries_id.lower()
    df_out = None

    for df, name in filtered_dataframes:
        df = standardize_columns(df, standardize_column_key)
        assert timeseries_id in df.columns, f'{timeseries_id} not included in all provided Dataframes'

        melted_df = pd.melt(df, id_vars=[timeseries_id], var_name=var_name, value_name=name)

        if df_out is None:
            df_out = melted_df
        else:
            # Ensure that the melted dataframe and the output dataframe have the same identifier columns
            melted_df.set_index([timeseries_id, var_name], inplace=True)
            df_out.set_index([timeseries_id, var_name], inplace=True)

            # Join the new data with the existing dataframe
            df_out = df_out.join(melted_df, how='left')
            df_out.reset_index(inplace=True)
    assert df_out is not None, 'Tables could not be combined, please check inputs provided'
    df_out.sort_values([timeseries_id, var_name], inplace=True)
    return df_out


def enrich_with_tabular_data(timeseries_data, tabular_static_data, timeseries_id='loan_id', standardize_column_key=0):
    for df, name in tabular_static_data:
        df = standardize_columns(df, standardize_column_key)
        assert timeseries_id in df.columns, f'{timeseries_id} not included in Dataframe with name {name}'
        timeseries_data.set_index(timeseries_id, inplace=True)
        df.set_index(timeseries_id, inplace=True)
        timeseries_data = timeseries_data.join(df, how='left')
        timeseries_data.reset_index(inplace=True)
    return timeseries_data


def add_metrics_to_df(df, metrics):
    for name, func in metrics.items():
        df[name] = func(df)
    return df


def create_timeseries_by_id_and_date(dataframes, metrics):
    """
    The assumption here is that data are either in a Loan level format or in a tabular format.
    This function can consume as many loan level data timeseries as we like.
    :param metrics:
    :param dataframes:
    :return:
    """
    keys = [key for key in dataframes.keys()]
    dataframes = [val for val in dataframes.values()]
    truth_table = check_date_columns(dataframes)
    filtered_dataframes = [(df, key) for df, truth, key in zip(dataframes, truth_table, keys) if truth]
    timeseries_df = combine_loan_level_data(filtered_dataframes)
    filtered_dataframes = [(df, key) for df, truth, key in zip(dataframes, truth_table, keys) if not truth]
    timeseries_df = enrich_with_tabular_data(timeseries_df, filtered_dataframes)
    timeseries_df = add_metrics_to_df(timeseries_df, metrics)

    return timeseries_df

