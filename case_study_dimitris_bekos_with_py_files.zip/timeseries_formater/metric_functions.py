import pandas as pd
import numpy as np

from timeseries_formater.constants import DELINQUENCY_MONTHS_TO_DEFAULT, SMALL_FLOAT


def current_balance(df):
    grouped = df.groupby('loan_id')
    df['current_balance'] = np.nan
    for name, group in grouped:
        initial_balance_set = False
        current_balance = np.nan
        for idx, row in group.iterrows():
            if np.isnan(group.loc[idx, 'MonthEndBalances']) and not initial_balance_set:
                continue
            elif not initial_balance_set:
                current_balance = df.loc[idx, 'MonthEndBalances']
                df.at[idx, 'current_balance'] = current_balance
                initial_balance_set = True
                continue

            current_balance -= df.loc[idx, 'PaymentMade'] - df.loc[idx, 'PaymentDue']
            df.at[idx, 'current_balance'] = current_balance
    return df['current_balance']


def seasoning(df):
    df['seasoning'] = pd.to_numeric(round((pd.to_datetime(df['date']) - df['origination_date']).dt.days / 30),
                                    downcast='integer')
    return df['seasoning']


def n_missed_payments(df):
    df['n_missed_payments'] = 0
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        missed_payments = 0
        for idx, row in group.iterrows():
            if row['PaymentDue'] > 0 and row['PaymentMade'] < row['PaymentDue']:
                missed_payments += 1
            else:
                missed_payments = 0
            df.at[idx, 'n_missed_payments'] = missed_payments
    return df['n_missed_payments']


def prepaid_in_month(df):
    df['prepaid_in_month'] = 0
    df.loc[np.logical_and(df['PaymentMade'] > df['PaymentDue'], df['MonthEndBalances'] == 0), 'prepaid_in_month'] = 1
    return df['prepaid_in_month']


def default_in_month(df):
    if 'n_missed_payments' not in df.columns:
        df['n_missed_payments'] = n_missed_payments(df)
    df['default_in_month'] = 0
    df.loc[df['n_missed_payments'] == DELINQUENCY_MONTHS_TO_DEFAULT, 'default_in_month'] = 1
    return df['default_in_month']


def is_recovery_payment(df):
    if 'default_in_month' not in df.columns:
        df['default_in_month'] = default_in_month(df)
    df['is_recovery_payment'] = 0
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        default_occurred = False
        for idx, row in group.iterrows():
            if row['default_in_month'] == 1:
                default_occurred = True
            elif default_occurred and row['PaymentMade'] > 0:
                df.at[idx, 'is_recovery_payment'] = 1
    return df['is_recovery_payment']


def time_to_reversion(df):
    df['time_to_reversion'] = pd.to_numeric(round((pd.to_datetime(df['date']) - df['reversion_date']).dt.days / 30),
                                    downcast='integer')
    return df['time_to_reversion']


def is_post_seller_purchase_date(df):
    df['is_post_seller_purchase_date'] = pd.to_numeric(
        round((pd.to_datetime(df['date']) - df['investor_1_acquisition_date']).dt.days / 30),
        downcast='integer')
    return df['is_post_seller_purchase_date']


def recovery_in_month(df):
    if 'default_in_month' not in df.columns:
        df['default_in_month'] = default_in_month(df)
    df['recovery_in_month'] = 0
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        default_occurred = False
        for idx, row in group.iterrows():
            if row['default_in_month'] == 1:
                default_occurred = True
            elif default_occurred and row['PaymentMade'] > 0:
                df.at[idx, 'recovery_in_month'] = 1
                # default_occurred = False  # Reset after recovery
    return df['recovery_in_month']


def postdefault_recoveries(df):
    if 'default_in_month' not in df.columns:
        df['default_in_month'] = default_in_month(df)
    df['postdefault_recoveries'] = np.nan
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        cumulative_recoveries = np.sum(group[np.where(group['default_in_month'] == 1)[0][0]:]['PaymentMade'])
        df.loc[group.index, 'postdefault_recoveries'] = cumulative_recoveries
    return df['postdefault_recoveries']


def prepayment_date(df):
    if 'prepaid_in_month' not in df.columns:
        df['prepaid_in_month'] = prepaid_in_month(df)
    df['prepayment_date'] = None
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        if not any(group['prepaid_in_month']):
            continue
        df.loc[group.index, 'prepayment_date'] = group.loc[group['prepaid_in_month'] == 1, 'date'].iloc[0]
    return df['prepayment_date']


def date_of_default(df):
    if 'default_in_month' not in df.columns:
        df['default_in_month'] = default_in_month(df)
    df['date_of_default'] = None
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        df.loc[group.index, 'date_of_default'] = group.loc[group['default_in_month'] == 1, 'date'].iloc[0]
    return df['date_of_default']


def date_of_recovery(df):
    if 'recovery_in_month' not in df.columns:
        df['recovery_in_month'] = recovery_in_month(df)
    df['date_of_recovery'] = None
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        if not any(group['recovery_in_month']):
            continue
        df.loc[group.index, 'date_of_recovery'] = group.loc[group['recovery_in_month'] == 1, 'date'].iloc[0]
    return df['date_of_recovery']


def exposure_at_default(df):
    if 'default_in_month' not in df.columns:
        df['default_in_month'] = default_in_month(df)
    df['exposure_at_default'] = np.nan
    grouped = df.groupby('loan_id')
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        df.loc[group.index, 'exposure_at_default'] = group.loc[group['default_in_month'] == 1, 'MonthEndBalances'].iloc[0]
    return df['exposure_at_default']


def recovery_percent(df):
    if 'postdefault_recoveries' not in df.columns:
        df['postdefault_recoveries'] = postdefault_recoveries(df)
    if 'exposure_at_default' not in df.columns:
        df['exposure_at_default'] = exposure_at_default(df)
    df['recovery_percent'] = df['postdefault_recoveries'] / df['exposure_at_default'] * 100
    return df['recovery_percent']


def prepayment_amount(df):
    grouped = df.groupby('loan_id')
    df['prepayment_amount'] = 0
    for name, group in grouped:
        df.loc[group.index, 'prepayment_amount'] = group['MonthEndBalances'].shift(1) - group['MonthEndBalances']


def portfolio_prepayment_rate(df, group_indices=['seasoning']):
    results = []

    grouped = df.groupby(group_indices)
    prepayment_amount(df)
    mortgages_that_defaulted_or_prepaid_before_t = np.zeros(df['loan_id'].max() + 1)

    for name, group in grouped:
        current_period_balance_excl_defaults = np.sum(group.loc[np.logical_not(mortgages_that_defaulted_or_prepaid_before_t[group['loan_id']]), 'MonthEndBalances'])
        current_period_prepayments = np.sum(group.loc[np.logical_not(mortgages_that_defaulted_or_prepaid_before_t[group['loan_id']]), 'prepayment_amount'])
        current_period_balance_excl_defaults = max(current_period_balance_excl_defaults, SMALL_FLOAT)
        # current_period_prepayments cause current_period_balance_excl_defaults to get to 0 so they should be added back
        # to the total balance
        current_period_balance_excl_defaults += current_period_prepayments

        smm = current_period_prepayments / current_period_balance_excl_defaults
        cpr = 1 - np.power(1 - smm, 12)
        dict1 = {f'{group_indices[i]}': int(name[i]) for i in range(len(group_indices))}
        dict1['CPR'] = cpr
        results.append(dict1)
        mortgages_that_defaulted_or_prepaid_before_t[group['loan_id']] += np.min([group['default_in_month'] + group['prepaid_in_month'], np.ones_like(group['prepaid_in_month'])], axis=0)

    cpr_df = pd.DataFrame(results).set_index(group_indices[0])
    cpr_df.sort_values(group_indices[::-1], inplace=True)
    return cpr_df


def cumulative_default_rate(df, group_indices=['seasoning']):
    results = []

    grouped = df.groupby(group_indices)
    previous_period_balance_excl_defaults = SMALL_FLOAT
    cdr_values = []
    mortgages_that_defaulted_or_prepaid_before_t = np.zeros(len(df))

    for name, group in grouped:

        current_period_balance_excl_defaults = np.max(
            [np.sum(group.loc[np.logical_not(mortgages_that_defaulted_or_prepaid_before_t[group.index]), 'MonthEndBalances']), SMALL_FLOAT])
        defaults = np.sum(group['default_in_month'] * group['exposure_at_default'])

        # current_period_prepayments cause current_period_balance_excl_defaults do NOT get to 0 so
        # no reason for them to be added back to the total balance

        mdr = defaults / current_period_balance_excl_defaults
        cdr = 1 - np.power(1 - mdr, 12)
        dict1 = {f'{group_indices[i]}': int(name[i]) for i in range(len(group_indices))}
        dict1['CDR'] = cdr
        results.append(dict1)

        mortgages_that_defaulted_or_prepaid_before_t[group.index] += np.min([group['default_in_month'] + group['prepaid_in_month'], np.ones_like(group['prepaid_in_month'])], axis=0)


    cdr_df = pd.DataFrame(results).set_index(group_indices[0])
    cdr_df.sort_values(group_indices[::-1], inplace=True)
    return cdr_df


def post_default_recovery_by_month(df):
    grouped = df.groupby('loan_id')
    df.loc[:, 'post_default_recovery_by_month'] = 0.0
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        group_default_date = group.loc[group['default_in_month'] == 1, 'date']
        for idx, row in group.iterrows():
            if row['date'] > group_default_date.values[0]:
                df.loc[idx, 'post_default_recovery_by_month'] = group.loc[idx, 'PaymentMade']


def cumulative_recovery_rate(df, group_indices=['seasoning']):
    results = []
    post_default_recovery_by_month(df)
    grouped = df.groupby(group_indices)
    recovery_values = []
    total_recoveries = 0
    total_defaults = 0
    for name, group in grouped:
        total_recoveries += np.sum(group['recovery_in_month'] * group['postdefault_recoveries'])
        total_defaults += np.sum(group['default_in_month'] * group['exposure_at_default'])
        recovery_rate = 100 * total_recoveries / total_defaults if total_defaults > 0 else 0
        dict1 = {f'{group_indices[i]}': int(name[i]) for i in range(len(group_indices))}
        dict1['Recovery'] = recovery_rate
        results.append(dict1)
    rec_df = pd.DataFrame(results).set_index(group_indices[0])
    rec_df.sort_values(group_indices[::-1], inplace=True)
    return rec_df


def months_since_default(df):
    grouped = df.groupby('loan_id')
    df.loc[:, 'months_since_default'] = -1
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        df.loc[group.index, 'months_since_default'] = pd.to_numeric(round(pd.to_timedelta(group['date'] - group['date_of_default']).dt.days / 30), downcast='integer')
    return df['months_since_default']


def year_of_default(df):
    grouped = df.groupby('loan_id')
    df.loc[:, 'year_of_default'] = -1
    for name, group in grouped:
        if not any(group['default_in_month']):
            continue
        df.loc[group.index, 'year_of_default'] = pd.to_datetime(group['date_of_default']).dt.year
    return df['year_of_default']


def create_probability_of_default(df, group_indices=['months_since_default', 'year_of_default']):
    results = []
    recoveries = 0
    total_defaults = 0
    grouped = df.groupby(group_indices)
    for name, group in grouped:
        if name[0] < 0:
            continue
        recoveries = np.sum(group['recovery_in_month'])
        total_defaults += np.sum(group['default_in_month'])
        dict1 = {f'{group_indices[i]}': int(name[i]) for i in range(len(group_indices))}
        dict1['Probability_of_recovery'] = recoveries / total_defaults if total_defaults > 0 else 0
        results.append(dict1)
    pd_df = pd.DataFrame(results).set_index(group_indices[0])
    pd_df.sort_values(group_indices[::-1], inplace=True)
    return pd_df


def create_recovery_rate_from_rec_over_ead(df, group_indices=['months_since_default', 'year_of_default']):
    results = []
    post_default_recovery_by_month(df)
    recoveries = np.zeros(df['loan_id'].max())
    total_defaults = 0
    grouped = df.groupby(group_indices)
    for name, group in grouped:
        if name[0] < 0:
            continue
        recoveries[group['loan_id']] += group['post_default_recovery_by_month']
        total_defaults = np.sum(group['exposure_at_default'])
        dict1 = {f'{group_indices[i]}': int(name[i]) for i in range(len(group_indices))}
        dict1['recovery_rate_from_rec_over_ead'] = np.sum(recoveries[group['loan_id']]) / total_defaults * 100 if total_defaults > 0 else 0
        results.append(dict1)
    pd_df = pd.DataFrame(results).set_index(group_indices[0])
    pd_df.sort_values(group_indices[::-1], inplace=True)
    return pd_df