def clean_column_names(df):
    column_list = df.columns.tolist()
    for i in range(len(column_list)):
        column_list[i] = str.strip(column_list[i])
    df.columns = column_list
    return df