import pandas as pd

from excel_parser.clean_column_names import clean_column_names


def cleanse_tabular_data(df):
    # Find the first row that has the same size as the next row and contains non-NaN values
    if not any("Unnamed" in str(col) for col in df.columns):
        return df  # Return the DataFrame as is if no cleansing is needed

    for i in range(len(df) - 1):
        row = df.iloc[i]
        next_row = df.iloc[i + 1]
        if len(row.dropna()) == len(next_row.dropna()) and not row.isnull().all():
            df.columns = row.astype(str)
            df = df[i + 1:]  # Remove the header row from the data
            break

    df = clean_column_names(df)

    # Drop columns where all values are NaN
    df = df.dropna(axis=1, how='all')

    # Reset index after dropping rows
    df = df.reset_index(drop=True)

    # Downcast data types to numeric
    for col in df.columns:
        try:
            df[col] = pd.to_numeric(df[col])
        except TypeError:
            try:
                df[col] = pd.to_datetime(df[col])
            except TypeError:
                raise TypeError

    # Reset index again after setting the new header
    df = df.reset_index(drop=True)

    return df


def load_and_clean_excel(file_path, read_all=False, data_pattern_name='DATA'):
    # Read the Excel file with all sheets
    excel_data = pd.read_excel(file_path, sheet_name=None)

    # Create a dictionary to hold dataframes for each sheet
    dataframes = {}
    data_shape = None
    # Iterate through each sheet in the Excel file
    for sheet_name, data in excel_data.items():
        if not read_all and data_pattern_name not in sheet_name.upper():
            print(f'Could not find {data_pattern_name} in the tab name of {sheet_name} please check the name of the excel tab')
            continue

        print(f'Parsing {sheet_name}..')
        formatted_name = sheet_name.replace(data_pattern_name + '-', '').replace(' ', '')
        dataframes[formatted_name] = cleanse_tabular_data(data)

        if data_shape:
            assert dataframes[formatted_name].shape[0] == data_shape, 'Check that number of loans is the same for all provided excel tabs'

        data_shape = dataframes[formatted_name].shape[0]
        print(f'{sheet_name} Parsed. Dataframe shape is {dataframes[formatted_name].shape}')
    return dataframes